function [evalDB,trajDB]=Evaluation_ct(x,Vr,goal,ob,R,model,evalParam)
% 

evalDB=[];
trajDB=[];
for vt=Vr(1):model(5):Vr(2) 
    for ot=Vr(3):model(6):Vr(4) 
        
        [xt,traj]=GenerateTrajectory(x,vt,ot,evalParam(4),model);  % evalParam(4) = 3
       
        heading=CalcHeadingEval(xt,goal); 
        dist=CalcDistEval(xt,ob,R);
        vel=abs(vt); 
      
        stopDist=CalcBreakingDist(vel,model);
        
        %%%%%%%         ****
        
        
        if dist>stopDist % 
            evalDB=[evalDB;[vt ot heading dist vel]]; 
            
            trajDB=[trajDB;traj]; 
        end
    end
end