function createfigure2(X1, YMatrix1)


figure1 = figure;

axes1 = axes('Parent',figure1);
hold(axes1,'on');

plot1 = plot(X1,YMatrix1);
set(plot1(1),'DisplayName','���ٶ�','Color',[0 0 1]);
set(plot1(2),'DisplayName','���ٶ�','Color',[1 0 0]);


xlabel('���ƽڵ����','FontSize',11);


ylabel('���ٶ�(m/s) ���ٶ�(rad/s)','FontSize',11);


set(axes1,'XTick',...
    [0 100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000 2100],...
    'YTick',[-0.4 -0.2 0 0.2 0.4 0.6 0.8]);
% ���� legend
legend1 = legend(axes1,'show');
set(legend1,...
    'Position',[0.809338793362948 0.188691530461689 0.0770870441239708 0.0732931707757545]);

