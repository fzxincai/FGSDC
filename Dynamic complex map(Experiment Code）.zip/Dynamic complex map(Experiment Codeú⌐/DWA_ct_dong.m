function a = DWA_ct_dong(Obs_dong,Obs_d_j,Area_MAX,Goal,cut_path,path_node,Start0,angle_node,Kinematic,evalParam)
figure
obstacle1=[0,0,0.4,30];
obstacle2=[0.4,0,29.6,0.4];
obstacle3=[0,29.6,30,0.4];
obstacle4=[29.6,0,0.4,29.5];
obstacle5=[0,5,2,2];
obstacle6=[0,7,2,2];
obstacle7=[0,9,2,2];
obstacle8=[0,11,2,2];
obstacle9=[0,12,2,2];
obstacle10=[0,13,2,2];
obstacle11=[0,15,2,2];
obstacle12=[2,5,2,2];

obstacle13=[6,3,2,2];
obstacle14=[8,3,2,2];
obstacle15=[8,5,2,2];

obstacle16=[5,10,2,2];
obstacle17=[5,12,2,2];
obstacle18=[7,12,2,2];
obstacle19=[7,10,2,2];

obstacle20=[0,20,2,2];
obstacle21=[0,22,2,2];
obstacle22=[0,24,2,2];
obstacle23=[0,26,2,2];
obstacle24=[2,20,2,2];
obstacle25=[2,22,2,2];
obstacle26=[2,24,2,2];
obstacle27=[2,26,2,2];

obstacle28=[6,22,2,4];
obstacle29=[10,20,2,2];
obstacle30=[10,22,2,2];

obstacle31=[12,14,2,2];
obstacle32=[12,16,2,2];

obstacle33=[15,10,2,2];
obstacle34=[15,12,2,2];
obstacle35=[17,10,2,2];
obstacle36=[17,12,2,2];

obstacle37=[14,0,2,2];
obstacle38=[14,2,2,2];
obstacle39=[14,4,2,2];
obstacle40=[16,0,2,2];
obstacle41=[16,2,2,2];
obstacle42=[16,4,2,2];
obstacle43=[18,0,2,2];
obstacle44=[18,2,2,2];
obstacle45=[18,4,2,2];

obstacle46=[16,16,2,2];
obstacle47=[16,18,2,2];
obstacle48=[18,16,2,2];
obstacle49=[18,18,2,2];
obstacle50=[20,16,2,2];
obstacle51=[20,18,2,2];
obstacle52=[22,16,2,2];
obstacle53=[22,18,2,2];

obstacle54=[22,6,2,2];
obstacle55=[24,6,2,2];

obstacle56=[24,0,2,2];
obstacle57=[24,2,2,2];
obstacle58=[26,0,2,2];
obstacle59=[26,2,2,2];

obstacle60=[28,15,2,2];
obstacle61=[28,17,2,2];
obstacle62=[28,19,2,2];
obstacle63=[28,21,2,2];
obstacle64=[28,23,2,2];

obstacle65=[14,26,2,2];
obstacle66=[16,26,2,2];
obstacle66=[16,26,2,2];
obstacle67=[16,26,2,2];
obstacle68=[18,26,2,2];
obstacle69=[20,26,2,2];
obstacle70=[22,26,2,2];
obstacle71=[18,24,2,2];


obstacle=[obstacle1;obstacle2;obstacle3;obstacle4;obstacle5;obstacle6;obstacle7;obstacle8;obstacle9;obstacle10;obstacle11;obstacle12;obstacle13;obstacle14;
    obstacle15;obstacle16;obstacle17;obstacle18;obstacle19;obstacle20;obstacle21;obstacle22;obstacle23;obstacle24;obstacle25;obstacle26;obstacle27;obstacle28;obstacle29;
    obstacle30;obstacle31;obstacle32;obstacle33;obstacle34;obstacle35;obstacle36;obstacle37;obstacle38;obstacle39;obstacle40;
    obstacle41;obstacle42;obstacle43;obstacle44;obstacle45;obstacle46;obstacle47;obstacle48;obstacle49;obstacle50;
    obstacle51;obstacle52;obstacle53;obstacle54;obstacle55;obstacle56;obstacle57;obstacle58;obstacle59;obstacle60;
    obstacle61;obstacle62;obstacle63;obstacle64;obstacle65;obstacle66;obstacle67;obstacle68;obstacle69;obstacle70;
    obstacle71];
obs=obstacle;


for i=1:size(obs,1)
Obs=[obs(:,1)+obs(:,3)./2 obs(:,2)+obs(:,4)./2];
end

num_obc=size(Obs,1); 
num_path=size(cut_path,1);
xTarget=path_node(num_path,1);
yTarget=path_node(num_path,2);
xm=path_node(1,1);
ym=path_node(1,2);
 %angle_S=pi;
 %=sn_angle(path_node(1,1),path_node(1,2),path_node(2,1),path_node(2,2));
 
 %zhuangjiao_node=angle_S-angle_node;
x=[xm ym angle_node 0 0]';
x_du=x;

%G_goal=path_node(num_path,:);

 
      
obstacleR=0.7;
global dt;  
dt=0.1;


MAX_X=Area_MAX(1,1);
MAX_Y=Area_MAX(1,2);

dong_guiji=[ ];
result.x=[];
goal=path_node(2,:);
ob_dong_num=size(Obs_dong,1);
tic;
% movcount=0;
% Main loop
for i=1:5000
  
    %goal=path_node(num_path,:);
    if i<=ob_dong_num
       obstacle=[Obs;Obs_d_j;Obs_dong(i,1) Obs_dong(i,2)];
       ob_i=i;
       dong_guiji=[dong_guiji;Obs_dong(i,1) Obs_dong(i,2)];
    else
       obstacle=[Obs;Obs_d_j;Obs_dong(ob_dong_num,1) Obs_dong(ob_dong_num,2)];
       ob_i=ob_dong_num;
    end
    
%    num_result=size(result.x,2);
    dang_node=[x(1,1) x(2,1)];
    dis_ng=distance(dang_node(1,1),dang_node(1,2),xTarget,yTarget);
    dis_x_du=distance(x_du(1,1),x_du(2,1),goal(1,1),goal(1,2));
    if num_path==2||dis_ng<2
        Ggoal=[xTarget yTarget];
    else
        Ggoal=Target_node(dang_node,path_node,Obs_dong,xTarget,yTarget,goal,dis_x_du);
    end
    goal=Ggoal;
    % obstacle=OBSTACLE(Obs_Closed,Obs_dong,path_node);
    
    [u,traj]=DynamicWindowApproach_ct(x,Kinematic,goal,evalParam,obstacle,obstacleR);
 
    x=f(x,u);
    x_du=f_du(x,u);
    result.x=[result.x; x'];

    

  
    %if norm(x(1:2)-G_goal')<0.2
    if dis_ng<0.2
        disp('Arrive Goal!!');break;
    end
    
    %====Animation====
    hold off;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

   
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    
    ArrowLength=0.5;% 

    quiver(x(1),   x(2),  ArrowLength*cos(x(3)),  ArrowLength*sin(x(3)),'ok');hold on;
    %  x=[x(m),y(m),yaw(Rad),v(m/s),w(rad/s)]
     plot(result.x(:,1), result.x(:,2),'-b','linewidth',1.5);hold on;
     plot(goal(1)',goal(2)','yo-','MarkerFaceColor','y');hold on;
  
     

    if ~isempty(traj)
        for it=1:length(traj(:,1))/5 % 
            ind=1+(it-1)*5;
            plot(traj(ind,:),traj(ind+1,:),'-g','linewidth',1.5);hold on;
        end
    end


     axis([0 MAX_X 0 MAX_Y])  
     for ob=1:size(obs,1)
      rectangle('position',[obs(ob,1),obs(ob,2),obs(ob,3),obs(ob,4)],'edgecolor','k','facecolor','k');
     end
     plot( cut_path(:,1), cut_path(:,2),'m:','linewidth',1.5); 
     plot(Start0(1,1),Start0(1,2),'go-','MarkerFaceColor','g','Markersize',10);
     plot(Goal(1,1),Goal(1,2),'ro-','MarkerFaceColor','r','Markersize',10);
   %  plot(+.5,+.5,'kp');
     fill([Obs_dong(ob_i,1)+0.15,Obs_dong(ob_i,1)+0.85,Obs_dong(ob_i,1)+0.85,Obs_dong(ob_i,1)+0.15],[Obs_dong(ob_i,2)+0.15,Obs_dong(ob_i,2)+0.15,Obs_dong(ob_i,2)+0.85,Obs_dong(ob_i,2)+0.85],'y');
      plot( dong_guiji(:,1)+.5, dong_guiji(:,2)+.5,'r:','linewidth',1); 
%     for i_g=1:1:Goal_COUNT
%       x_go=Goal(i_g,1);
%       y_go=Goal(i_g,2);
%       plot(x_go+.5,y_go+.5,'bo');
%      % text(x_go+1,y_go+1.5,num2str(i_g,'T(%d)'),'fontsize',18');
%     end
    dong_num=size(Obs_d_j,1);
    for i_d=1:1:dong_num
      x_do=Obs_d_j(i_d,1);
      y_do=Obs_d_j(i_d,2);
      fill([x_do,x_do+1,x_do+1,x_do],[y_do,y_do,y_do+1,y_do+1],[1 0 0]);
    end
    grid on; 
    drawnow;
    %movcount=movcount+1;
    %mov(movcount) = getframe(gcf);% 
    
end

a=result.x;
toc
%movie2avi(mov,'movie.avi');
 





 

 

 

 

 

