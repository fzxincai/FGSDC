function createfigure3(X1, YMatrix1)
%CREATEFIGURE(X1, YMATRIX1)




figure1 = figure;


axes1 = axes('Parent',figure1);
hold(axes1,'on');


plot1 = plot(X1,YMatrix1);
set(plot1(1),'DisplayName','s','Color',[0 0 1]);
set(plot1(2),'DisplayName','v','Color',[1 0 0]);


xlabel('b','FontSize',11);


ylabel('d(m/s) g(rad/s)','FontSize',11);


set(axes1,'XTick',...
    [0 100 200 300 400 500 600 700 800 900 1000 1100 1200 1300 1400 1500 1600 1700 1800 1900 2000 2100],...
    'YTick',[-0.4 -0.2 0 0.2 0.4 0.6 0.8]);

legend1 = legend(axes1,'show');
set(legend1,...
    'Position',[0.826100061247333 0.206397316431758 0.0696202521944994 0.0737373718107587]);

