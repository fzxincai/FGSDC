function [u,trajDB]=DynamicWindowApproach_du(x,model,goal,evalParam,ob,R,Obs_dong,R_dong_obs)

model(3)=0;
model(5)=0;
Vr=CalcDynamicWindow_du(x,model);

[evalDB,trajDB]=Evaluation_du(x,Vr,goal,ob,R,model,evalParam,Obs_dong,R_dong_obs);

if isempty(evalDB)   
    disp('no path to goal!!');
    u=[0;0];return;
end

evalDB=NormalizeEval(evalDB);
feval=[]; 
for id=1:length(evalDB(:,1))
    feval=[feval;evalParam(1:4)*evalDB(id,3:6)'];
    
end
evalDB=[evalDB feval];
 
[maxv,ind]=max(feval);
u=evalDB(ind,1:2)';% 