function dist=CalcDistEval(x,ob,R)

dist=200;
for io=1:length(ob(:,1))
    disttmp=norm(ob(io,:)-x(1:2)')-R;
    if dist>disttmp
        dist=disttmp;
    end
end
 

if dist>=R
    dist=R;
end