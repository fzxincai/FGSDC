function Obst_d_d_line=Line_obst(Obst_d_path_X,L_obst)
num=size(Obst_d_path_X,1);

Obst_d_d_line=[];
for v=1:1:(num-1)
       
       
        p_node_1=[Obst_d_path_X(v,1),Obst_d_path_X(v,2)]; 
        p_node_2=[Obst_d_path_X(v+1,1),Obst_d_path_X(v+1,2)] ; 
       
        line_node=LINE_o2(p_node_1,p_node_2,L_obst); 
        
        Obst_d_d_line=[Obst_d_d_line;line_node];
      
end