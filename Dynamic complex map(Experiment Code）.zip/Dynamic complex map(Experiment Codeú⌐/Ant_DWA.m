%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear;
close all;
figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                         
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
global A;
global B;
x_max = 30;
y_max = 30;
x_val = 1;
y_val = 1;
Area_MAX(1,1)=x_max;
MAX_X=Area_MAX(1,1);
Area_MAX(1,2)=y_max;
MAX_Y=Area_MAX(1,2);
MAX=[MAX_X,MAX_Y];
global obstacle111;global obstacle222;global obstacle333;global obstacle444;global obstacle555;global obstacle666;global obstacle777;
global obstacle888;global obstacle999;global obstacle101;global obstacle102;global obstacle103;global obstacle104;global obstacle105;
global obstacle106;global obstacle107;global obstacle108;global obstacle109;global obstacle100;global obstacle202;
global obstacle203;global obstacle204;global obstacle205;global obstacle206;
obstacle111 = [5,10,4,4];   
obstacle222 = [15,10,4,4];  
obstacle333 = [10,20,2,4];  
obstacle444=[0,20,4,8];
obstacle555=[6,22,2,4];
obstacle666=[0,5,2,12];
obstacle777=[2,5,2,2];
obstacle888=[8,5,2,2];
obstacle999=[6,3,4,2];
obstacle101=[14,0,6,6];
obstacle102=[24,0,4,4];
obstacle103=[24,6,2,2];
obstacle104=[24,6,2,2];
obstacle105=[22,6,2,2];
obstacle106=[28,15,4,10];
obstacle107=[12,14,2,4];
obstacle108=[14,26,10,2];
obstacle109=[20,26,2,2];
% obstacle100=[16,18,8,2];
obstacle100=[16,16,8,4];
% obstacle200=[16,16,2,2];
% obstacle201=[22,16,2,2];
obstacle202=[18,24,2,2];

obstacle203=[0,0,0.4,30];
obstacle204=[0.4,0,29.6,0.4];
obstacle205=[0,29.6,30,0.4];
obstacle206=[29.6,0,0.4,29.5];

% obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
%     obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle200;obstacle201;obstacle202
%     obstacle203;obstacle204;obstacle205;obstacle206];
obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
    obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle202
    obstacle203;obstacle204;obstacle205;obstacle206];
axis([0 x_max 0 y_max]);
for i=1:size(obstacle,1)
    rectangle('Position',obstacle(i,:),'edgecolor','k','facecolor','k')
end
grid on;
hold on;
Num_obs=size(obstacle,1); 


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

A=[1 1];
B=[27 27];
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
hold on
 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                             
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
cut_path=mainRRT(A,B,obstacle111,obstacle222,obstacle333,obstacle444,obstacle555,obstacle666,obstacle777,obstacle888,obstacle999,obstacle101,obstacle102,obstacle103,obstacle104,obstacle105,obstacle106,obstacle107,obstacle108,obstacle109,obstacle100,obstacle202,obstacle203,obstacle204,obstacle205,obstacle206);
 global B;
disp('Global static time planning')
toc
pause(0.1);
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
S=0;
  j = size(cut_path,1) ;
 for i=1:1:(j-1)  
      Dist=sqrt( (cut_path(i,1) - cut_path(i+1,1) )^2 + (cut_path(i,2) - cut_path(i+1,2))^2);
      S=S+Dist;
  end
  disp('Path length planned globally statically')
  S 

Start=floor(A);
Goal=floor(B);
figure 
axis([0 MAX_X 0 MAX_Y])    
grid on;       
hold on;
num_obc=size(obstacle,1);
 for ob=1:1:num_obc
   rectangle('position',[obstacle(ob,1),obstacle(ob,2),obstacle(ob,3),obstacle(ob,4)],'edgecolor','k','facecolor','k');hold on;
 end
 for io=2:size(cut_path,1)-1
    plot(cut_path(io,1)',cut_path(io,2)','yo-','MarkerFaceColor','y')
end
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
plot( cut_path(:,1), cut_path(:,2),'m:','linewidth',1);  
pause(0.1)
% 
pause(1);
h=msgbox('start1');
uiwait(h,5);
if ishandle(h) == 1
    delete(h);
end
xlabel('start2');
but=0;
while (but ~= 1) %Repeat until the Left button is not clicked
    [xval,yval,but]=ginput(1);
end
xval=floor(xval);
yval=floor(yval);
Obst_xS=xval;%X Coordinate of the Target
Obst_yS=yval;%Y Coordinate of the Target

plot(xval+.5,yval+.5,'k^');
 
pause(1);

h=msgbox('end1');
uiwait(h,5);
if ishandle(h) == 1
    delete(h);
end
xlabel('end2');
but=0;
while (but ~= 1) %Repeat until the Left button is not clicked
    [xval,yval,but]=ginput(1);
    xval=floor(xval);
    yval=floor(yval);
end
Obst_xT=xval;%Starting Position
Obst_yT=yval;%Starting Position
 plot(xval+.5,yval+.5,'ko');
 Obst_d_d_St=[Obst_xS Obst_yS];
Obst_d_d_Ta=[Obst_xT Obst_yT];
[Obst_d_path,Obst_d_distance_x,Obst_d_OPEN_num]=Astar(Obst_d_d_St,Obst_d_d_Ta);
Obst_d_path_X=[Obst_d_path;Obst_d_d_Ta];
L_obst=0.01;
Obst_d_d_line=Line_obst(Obst_d_path_X,L_obst);
plot( Obst_d_d_line(:,1), Obst_d_d_line(:,2),'r','linewidth',1); 

pause(1);
h=msgbox('static obs');
  xlabel('Set unknown static obstacles left click confirm to continue setting, right click confirm to end','Color','blue');
uiwait(h,10);
if ishandle(h) == 1
    delete(h);
end
but=1;
while but == 1
    [xval,yval,but] = ginput(1);
    xval=floor(xval);
    yval=floor(yval);
    MAX(xval,yval)=8;
    %plot(xval+.5,yval+.5,'rp');
    fill([xval,xval+1,xval+1,xval],[yval,yval,yval+1,yval+1],[1 0 0]); 
 end%End of While loop


dg=0;%Dummy counter
Obs_d_j=[0 0 ];
for i=1:MAX_X
    for j=1:MAX_Y
        if((i== xval)&&(j==yval))
            dg=dg+1;
            Obs_d_j(dg,1)=i; 
            Obs_d_j(dg,2)=j; 
        end
    end
end
     

 %%%%%%%%%%%%%%%           %%%%%%%%%%%%%%%%%%%%%
% 
tic
angle_node=pi/4;
Kinematic=[1.5,toRadian(20.0),0.2,toRadian(50.0),0.02,toRadian(1)];
evalParam=[0.15,0.2,0.3,3.0];%


path_node=cut_path;
Result_x=DWA_ct_dong(Obst_d_d_line,Obs_d_j,Area_MAX,Goal,cut_path,path_node,Start,angle_node,Kinematic,evalParam);
disp('Local dynamic programming time (actual moving time)')
toc
S_dwa=0;
 j = size(Result_x,1) ;
 for i=1:1:(j-1)  
     Dist=sqrt( ( Result_x(i,1) - Result_x(i+1,1) )^2 + ( Result_x(i,2) - Result_x(i+1,2))^2);
     S_dwa=S_dwa+Dist;
 end
 disp('Local path length��')
 S_dwa 
 %%%
 plot(Result_x(:,1), Result_x(:,2),'-b','linewidth',1.5);hold on;
 num_x=size(Result_x,1);
 ti=1:1:num_x;

 
 
 