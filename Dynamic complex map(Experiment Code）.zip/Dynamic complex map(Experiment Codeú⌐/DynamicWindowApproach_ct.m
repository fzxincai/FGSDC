function [u,trajDB]=DynamicWindowApproach_ct(x,model,goal,evalParam,ob,R)

Vr=CalcDynamicWindow(x,model);

[evalDB,trajDB]=Evaluation_ct(x,Vr,goal,ob,R,model,evalParam);

if isempty(evalDB)  
    disp('no path to goal!!');
    u=[0;0];return;
end

evalDB=NormalizeEval_ct(evalDB);

feval=[]; 
for id=1:length(evalDB(:,2))
    feval=[feval;evalParam(1:3)*evalDB(id,3:5)'];
    
end
evalDB=[evalDB feval];
 
[maxv,ind]=max(feval);
u=evalDB(ind,1:2)';% 