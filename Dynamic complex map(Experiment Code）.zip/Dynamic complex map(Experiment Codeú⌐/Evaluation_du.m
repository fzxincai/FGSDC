function [evalDB,trajDB]=Evaluation_du(x,Vr,goal,ob,R,model,evalParam,Obs_dong,R_dong_obs)

evalDB=[];
trajDB=[];

    vt=0;
    for ot=Vr(3):model(6):Vr(4) 
       
        [xt,traj]=GenerateTrajectory(x,vt,ot,evalParam(5),model);  % evalParam(4) = 3
        
        heading=CalcHeadingEval(xt,goal); 
        dist=0;%CalcDistEval(xt,ob,R); 
        vel=abs(vt); 
       
   
        %dist_dong=Dist_Obs_dong(Obs_dong,xt,R_dong_obs);
        
        %if dist>stopDist % 
            evalDB=[evalDB;[vt ot heading dist vel 0 ]]; 
           
            trajDB=[trajDB;traj]; 
       % end
    end
%end