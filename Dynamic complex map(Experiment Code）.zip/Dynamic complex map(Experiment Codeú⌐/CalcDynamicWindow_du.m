function Vr=CalcDynamicWindow_du(x,model)
%
global dt;

Vs=[0 0 -model(2) model(2)];


Vd=[0 0 x(5)-model(4)*dt x(5)+model(4)*dt];

Vtmp=[Vs;Vd];

Vr=[0 0 max(Vtmp(:,3)) min(Vtmp(:,4))];
