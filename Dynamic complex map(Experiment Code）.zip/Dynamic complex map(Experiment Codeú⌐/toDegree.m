function degree = toDegree(radian)
% radian to degree
degree = radian/pi*180;