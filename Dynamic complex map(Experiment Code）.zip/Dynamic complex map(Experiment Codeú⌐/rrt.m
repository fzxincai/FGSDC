
function rrts = rrt
rrts.isEdgeCollisionFree= @isEdgeCollisionFree;           % �ж�����֮���������û���ϰ���
rrts.isOutOfBounds = @isOutOfBounds;                      % �жϵ��Ƿ񳬳��ϰ���
rrts.euclidian_dist = @euclidian_dist;                    % ��������֮��ľ���
rrts.arangel= @ arangel;                                  % �����������ļн�
rrts.direction = @direction;                              % ������������
rrts.samplesobol = @samplesobol;                          % ����Sobol����
rrts.nearestpoint = @nearestpoint;                        % ��������ڵ�
rrts.nearestpoint2 = @nearestpoint2;                      % ����ڶ�����������ڵ�
rrts.angel_dist = @angel_dist;                            % ����ؽڽ�֮��ľ���
rrts.newpoint = @newpoint;                                % �����½ڵ�
rrts.findparentpoint = @findparentpoint;                  % Ѱ�ҵ�ǰ�ڵ�ĸ��ڵ�
rrts.ccw=@ccw;
rrts.noCollision=@noCollision;
rrts.APF_newpoint=@APF_newpoint;
rrts.REP_newpoint=@REP_F;
rrts.angel_limit=@angel_limit;
end

function val = ccw(A,B,C)
    val = (C(2)-A(2)) * (B(1)-A(1)) > (B(2)-A(2)) * (C(1)-A(1));
end

function nc = noCollision(n2, n1, o)
    A = [n1(1) n1(2)];
    B = [n2(1) n2(2)];
    obs = [o(1) o(2) o(1)+o(3) o(2)+o(4)];   
    C1 = [obs(1),obs(2)];
    D1 = [obs(1),obs(4)];
    C2 = [obs(1),obs(2)];
    D2 = [obs(3),obs(2)];
    C3 = [obs(3),obs(4)];
    D3 = [obs(3),obs(2)];
    C4 = [obs(3),obs(4)];
    D4 = [obs(1),obs(4)];
    ints1 = ccw(A,C1,D1) ~= ccw(B,C1,D1) && ccw(A,B,C1) ~= ccw(A,B,D1); 
    ints2 = ccw(A,C2,D2) ~= ccw(B,C2,D2) && ccw(A,B,C2) ~= ccw(A,B,D2);
    ints3 = ccw(A,C3,D3) ~= ccw(B,C3,D3) && ccw(A,B,C3) ~= ccw(A,B,D3);
    ints4 = ccw(A,C4,D4) ~= ccw(B,C4,D4) && ccw(A,B,C4) ~= ccw(A,B,D4);
    if ints1==0 && ints2==0 && ints3==0 && ints4==0
        nc = 1;
    else
        nc = 0;
    end
end



% ��������ȷ��������
function [dir] = direction(pose1,pose2)
    dir1 = pose2(1)-pose1(1);
    dir2 = pose2(2)-pose1(2);
    dir = [dir1 dir2];   
end


% ����������֮��ļн�(����������1��ʼ)
function Flag = angel_limit(path,xnear,xnew)
    global angle;
    if xnear(3)<0
        Flag = 1;
    else
        xinit = path(xnear(3),1:3);
        A = [xinit(1)-xnear(1),xinit(2)-xnear(2)];
        B = [xnew(1)-xnear(1),xnew(2)-xnear(2)];
        thea = acos(dot(A,B)/(norm(A)*norm(B)))*180/pi;
        if thea>=angle
            Flag = 1;
        else
            Flag = 0; 
        end
    end
end

% ������֮��ľ���
function [angel_len] = angel_dist(pose1,pose2)
    angel_len = norm((pose2-pose1),2);
end


% ��������ڵ�
function [thea_dis,I]= nearestpoint(random_point)
    global path_V;
    min_dis = inf;
    for i = 1: size(path_V,1)
        if(min_dis>angel_dist(random_point,path_V(i,1:2)))
            min_dis = angel_dist(random_point,path_V(i,1:2));
            thea_dis = [path_V(i,1:3)];
            I = i;
        end        
    
    end
end



% ���ݲ������½ڵ�
function [new_thea] = newpoint(near_point,random_point)
    global step;
    len = norm((random_point - near_point(1:2)),2);
    if(len < step)
        new_thea = random_point;
    else
        dir = (random_point - near_point(1:2))/len;
        new_thea = near_point(1:2) + dir*step;
    end
end


% ������������������Ľڵ����ɺ���(����ڵ㣬������)
function [new_thea] = APF_newpoint(near_point,random_point)
    global obstacle11;global obstacle22;global obstacle33;global obstacle44;global obstacle55;global obstacle66;global obstacle77;global obstacle88;global obstacle99;
    global obstacle10;global obstacle12;global obstacle13;global obstacle14;global obstacle15;global obstacle16;global obstacle17;global obstacle18;global obstacle19;global obstacle20;
    global obstacle24;
    global step;
    global goal_pose;
    global kp;
%     R=5;                             
    global tem_step;
    len = norm((random_point - near_point(1:2)),2);           % ������������ڵ�ľ���
    len1 = norm((goal_pose -near_point(1:2)),2);             % Ŀ���������ڵ�ľ���
    if noCollision(random_point, near_point, obstacle11)&&noCollision(random_point, near_point, obstacle22)&&noCollision(random_point, near_point, obstacle33)&&noCollision(random_point, near_point, obstacle44)&&noCollision(random_point, near_point, obstacle55)&&noCollision(random_point, near_point, obstacle66)&&noCollision(random_point, near_point, obstacle77)&&noCollision(random_point, near_point, obstacle88)&&noCollision(random_point, near_point, obstacle99) ...
    &&noCollision(random_point, near_point, obstacle10)&&noCollision(random_point, near_point, obstacle12)&&noCollision(random_point, near_point, obstacle13)&&noCollision(random_point, near_point, obstacle14)&&noCollision(random_point, near_point, obstacle15)&&noCollision(random_point, near_point, obstacle16)&&noCollision(random_point, near_point, obstacle17)&&noCollision(random_point, near_point, obstacle18)&&noCollision(random_point, near_point, obstacle19)...
    &&noCollision(random_point, near_point, obstacle20)&&noCollision(random_point, near_point, obstacle24)
%  &&noCollision(random_point, near_point, obstacle21)&&noCollision(random_point, near_point, obstacle23)
    
           tem_step = len;
        else
        tem_step = step;
    end
%     if(len < step)
%         tem_step = len;
%     else
%         tem_step = step;
%     end
    U = (random_point - near_point(1:2))/len+kp*(goal_pose - near_point(1:2))/len1;
    new_thea = near_point(1:2)+tem_step*U/norm(U,2);
end















