%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


clear;
close all;
figure
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

global A;
global B;
x_max = 30;
y_max = 30;
x_val = 1;
y_val = 1;
Area_MAX(1,1)=x_max;
MAX_X=Area_MAX(1,1);
Area_MAX(1,2)=y_max;
MAX_Y=Area_MAX(1,2);
MAX=[MAX_X,MAX_Y];
global obstacle111;global obstacle222;global obstacle333;global obstacle444;global obstacle555;global obstacle666;global obstacle777;
global obstacle888;global obstacle999;global obstacle101;global obstacle102;global obstacle103;global obstacle104;global obstacle105;
global obstacle106;global obstacle107;global obstacle108;global obstacle109;global obstacle100;global obstacle202;
global obstacle203;global obstacle204;global obstacle205;global obstacle206;
obstacle111 = [5,10,4,4];   
obstacle222 = [15,10,4,4];  
obstacle333 = [10,20,2,4];  
obstacle444=[0,20,4,8];
obstacle555=[6,22,2,4];
obstacle666=[0,5,2,12];
obstacle777=[2,5,2,2];
obstacle888=[8,5,2,2];
obstacle999=[6,3,4,2];
obstacle101=[14,0,6,6];
obstacle102=[24,0,4,4];
obstacle103=[24,6,2,2];
obstacle104=[24,6,2,2];
obstacle105=[22,6,2,2];
obstacle106=[28,15,4,10];
obstacle107=[12,14,2,4];
obstacle108=[14,26,10,2];
obstacle109=[20,26,2,2];
% obstacle100=[16,18,8,2];
obstacle100=[16,16,8,4];
% obstacle200=[16,16,2,2];
% obstacle201=[22,16,2,2];
obstacle202=[18,24,2,2];

obstacle203=[0,0,0.4,30];
obstacle204=[0.4,0,29.6,0.4];
obstacle205=[0,29.6,30,0.4];
obstacle206=[29.6,0,0.4,29.5];

% obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
%     obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle200;obstacle201;obstacle202
%     obstacle203;obstacle204;obstacle205;obstacle206];
obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
    obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle202
    obstacle203;obstacle204;obstacle205;obstacle206];
axis([0 x_max 0 y_max]);
for i=1:size(obstacle,1)
    rectangle('Position',obstacle(i,:),'edgecolor','k','facecolor','k')
end
grid on;
hold on;
Num_obs=size(obstacle,1);  

A=[1 1];
B=[27 27];
plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
hold on

% %                             
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tic
  cut_path=mainRRT(A,B,obstacle111,obstacle222,obstacle333,obstacle444,obstacle555,obstacle666,obstacle777,obstacle888,obstacle999,obstacle101,obstacle102,obstacle103,obstacle104,obstacle105,obstacle106,obstacle107,obstacle108,obstacle109,obstacle100,obstacle202,obstacle203,obstacle204,obstacle205,obstacle206)
  global B;
disp('Global planning time')
toc

 S=0;
  j = size(cut_path,1) ;
 for i=1:1:(j-1)  
      Dist=sqrt( (cut_path(i,1) - cut_path(i+1,1) )^2 + (cut_path(i,2) - cut_path(i+1,2))^2);
      S=S+Dist;
  end
  disp('Global path length')
  S 

  % %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% %                            
% %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% 
pause(0.1);
figure

axis([0 MAX_X 0 MAX_Y]) 
grid on;       
hold on;
num_obc=size(obstacle,1);

 for ob=1:1:num_obc
   rectangle('position',[obstacle(ob,1),obstacle(ob,2),obstacle(ob,3),obstacle(ob,4)],'edgecolor','k','facecolor','k');hold on;
 end

 plot( cut_path(:,1), cut_path(:,2),'m:','linewidth',2);
plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
 for io=2:size(cut_path,1)-1
    plot(cut_path(io,1)',cut_path(io,2)','yo-','MarkerFaceColor','y')
end
pause(0.1);

h=msgbox('Use the left mouse button to select the first dynamic obstacle location');                   
uiwait(h,5);
if ishandle(h) == 1
    delete(h);
end
xlabel('Use the left mouse button to select the location of the dynamic obstacle ','Color','black');             
but=0;
while (but ~= 1)             
    [start_pose1(1),start_pose1(2),but]=ginput(1);
    xval=floor(start_pose1(1));
    yval=floor(start_pose1(2));
end
Obs_dong(1,1)=xval;%Starting Position
Obs_dong(1,2)=yval;%Starting Position
fill([xval,xval+2,xval+2,xval],[yval,yval,yval+2,yval+2],[1 0 0]);                                          

pause(0.1);
h=msgbox('d');
  
uiwait(h,10);
if ishandle(h) == 1
    delete(h);
end
while but == 1
    [start_pose1(1),start_pose1(2),but] = ginput(1);
    xval=floor(start_pose1(1));
    yval=floor(start_pose1(2));
%     MAX(xval,yval)=-2;%Put on the closed list as well
    fill([xval,xval+2,xval+2,xval],[yval,yval,yval+2,yval+2],[1 0 0]);
 end%End of While loop
 
dg=1;%Dummy counter
 for i=1:MAX_X
     for j=1:MAX_Y


        
          if((i== xval)&&(j==yval))
             dg=dg+1;
            Obs_dong(dg,1)=i; 
            Obs_dong(dg,2)=j; 
           % text(i+1,j+1.5,num2str(dg,'T(%d)'),'fontsize',18')
           
          end
         
    end
    end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                              
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tic
Result_x=DWA(Obs_dong,Area_MAX,cut_path,A,B);
disp('Local planning time')
toc

S_dwa=0;
 j = size(Result_x,1) ;
 for i=1:1:(j-1)  
     Dist=sqrt( ( Result_x(i,1) - Result_x(i+1,1) )^2 + ( Result_x(i,2) - Result_x(i+1,2))^2);
     S_dwa=S_dwa+Dist;
 end
 disp('Local path length')
 S_dwa 
 %%%
 plot(Result_x(:,1), Result_x(:,2),'-b','linewidth',1.5);hold on;
 num_x=size(Result_x,1);
 ti=1:1:num_x;
