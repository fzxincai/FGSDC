function Tg=Target_node(dang_node,path,Obs_dong,xTarget,yTarget,goal)
   num_path=size(path,1);
   num_Obs_dong=size(Obs_dong,1);
   n_index = Optimal_index(path,goal(1,1),goal(1,2));
   path_dis=[0 0];
   distan_d_g = distance(dang_node(1,1),dang_node(1,2),goal(1,1),goal(1,2));
    
   
    
   for i=1:1:num_Obs_dong  
        path_dis(i,1)=Obs_dong(i,1);
        path_dis(i,2)=Obs_dong(i,2);
        path_dis(i,3)=distance(goal(1,1),goal(1,2),Obs_dong(i,1),Obs_dong(i,2));
        %path_dis(i,4)=i;
   end
    [min_dis,temp_min]=min(path_dis(:,3)); 
    dis_d_minObs=distance(dang_node(1,1),dang_node(1,2),Obs_dong(temp_min,1),Obs_dong(temp_min,2));
    
    if n_index<num_path
       if distan_d_g<2 || ( min_dis<2&&dis_d_minObs<2)
          Tg=[path(n_index+1,1) path(n_index+1,2)];
       else
          Tg = goal;
       end
    else
        Tg=[xTarget yTarget];
    end
 
    


