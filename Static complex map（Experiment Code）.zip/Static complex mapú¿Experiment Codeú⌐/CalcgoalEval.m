function goaldist=CalcgoalEval(x,B)

    goaldist=100;
  
   disttmp1=norm(B-x(1:2)')- 2;
    if goaldist>disttmp1
        goaldist=disttmp1;
    else
         goaldist=0;
    end
