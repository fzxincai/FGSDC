function radian = toRadian(degree)
% degree to radian
radian = degree/180*pi;