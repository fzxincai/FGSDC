function constrained= checkConstraint(p1,p2,sign)
p1=p1-0.5;
p2=p2-0.5;
n=ceil(norm(p1-p2)*10);
node_lin=zeros(n,2);
for i=1:n
    node_lin(i,:)=p1+(p2-p1)*i/n;
end
constrained = 0;
for i=1:n
    p_lin=node_lin(i,:);
    p_lin=ceil(p_lin);
    if sign(p_lin(1),p_lin(2))==1
        constrained = 1;
        break;
    end
end