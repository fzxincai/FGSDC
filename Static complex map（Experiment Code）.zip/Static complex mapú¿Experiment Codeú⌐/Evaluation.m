function [evalDB,trajDB]=Evaluation(x,Vr,goal,ob,R,model,evalParam,B)
% 
evalDB=[];
trajDB=[];
for vt=Vr(1):model(5):Vr(2)
    for ot=Vr(3):model(6):Vr(4)
       
        [xt,traj]=GenerateTrajectory(x,vt,ot,evalParam(5),model);  
        heading=CalcHeadingEval(xt,goal);
        dist=CalcDistEval(xt,ob,R);
        vel=abs(vt);
        goaldist=CalcgoalEval(x,B);
 
        stopDist=CalcBreakingDist(vel,model);
        if dist>stopDist % 
            evalDB=[evalDB;[vt ot heading dist vel goaldist ]];
            trajDB=[trajDB;traj];
        end
    end
end