function a = DWA(Obs_dong,Area_MAX,cut_path,A,B)
figure(2)
A=floor(A);
B=floor(B);
Line_path=cut_path;
% obstacle1=[0,0,0.4,30];
% obstacle2=[0.4,0,29.6,0.4];
% obstacle3=[0,29.6,30,0.4];
% obstacle4=[29.6,0,0.4,29.5];
% obstacle5=[0,5,2,2];
% obstacle6=[0,7,2,2];
% obstacle7=[0,9,2,2];
% obstacle8=[0,11,2,2];
% obstacle9=[0,12,2,2];
% obstacle10=[0,13,2,2];
% obstacle11=[0,15,2,2];
% obstacle12=[2,5,2,2];
% 
% obstacle13=[6,3,2,2];
% obstacle14=[8,3,2,2];
% obstacle15=[8,5,2,2];
% 
% obstacle16=[5,10,2,2];
% obstacle17=[5,12,2,2];
% obstacle18=[7,12,2,2];
% obstacle19=[7,10,2,2];
% 
% obstacle20=[0,20,2,2];
% obstacle21=[0,22,2,2];
% obstacle22=[0,24,2,2];
% obstacle23=[0,26,2,2];
% obstacle24=[2,20,2,2];
% obstacle25=[2,22,2,2];
% obstacle26=[2,24,2,2];
% obstacle27=[2,26,2,2];
% 
% obstacle28=[6,22,2,4];
% obstacle29=[10,20,2,2];
% obstacle30=[10,22,2,2];
% 
% obstacle31=[12,14,2,2];
% obstacle32=[12,16,2,2];
% 
% obstacle33=[15,10,2,2];
% obstacle34=[15,12,2,2];
% obstacle35=[17,10,2,2];
% obstacle36=[17,12,2,2];
% 
% obstacle37=[14,0,2,2];
% obstacle38=[14,2,2,2];
% obstacle39=[14,4,2,2];
% obstacle40=[16,0,2,2];
% obstacle41=[16,2,2,2];
% obstacle42=[16,4,2,2];
% obstacle43=[18,0,2,2];
% obstacle44=[18,2,2,2];
% obstacle45=[18,4,2,2];
% 
% obstacle46=[16,16,2,2];
% obstacle47=[16,18,2,2];
% obstacle48=[18,16,2,2];
% obstacle49=[18,18,2,2];
% obstacle50=[20,16,2,2];
% obstacle51=[20,18,2,2];
% obstacle52=[22,16,2,2];
% obstacle53=[22,18,2,2];
% 
% obstacle54=[22,6,2,2];
% obstacle55=[24,6,2,2];
% 
% obstacle56=[24,0,2,2];
% obstacle57=[24,2,2,2];
% obstacle58=[26,0,2,2];
% obstacle59=[26,2,2,2];
% 
% obstacle60=[28,15,2,2];
% obstacle61=[28,17,2,2];
% obstacle62=[28,19,2,2];
% obstacle63=[28,21,2,2];
% obstacle64=[28,23,2,2];
% 
% obstacle65=[14,26,2,2];
% obstacle66=[16,26,2,2];
% obstacle66=[16,26,2,2];
% obstacle67=[16,26,2,2];
% obstacle68=[18,26,2,2];
% obstacle69=[20,26,2,2];
% obstacle70=[22,26,2,2];
% obstacle71=[18,24,2,2];
% 
% 
% obstacle=[obstacle1;obstacle2;obstacle3;obstacle4;obstacle5;obstacle6;obstacle7;obstacle8;obstacle9;obstacle10;obstacle11;obstacle12;obstacle13;obstacle14;
%     obstacle15;obstacle16;obstacle17;obstacle18;obstacle19;obstacle20;obstacle21;obstacle22;obstacle23;obstacle24;obstacle25;obstacle26;obstacle27;obstacle28;obstacle29;
%     obstacle30;obstacle31;obstacle32;obstacle33;obstacle34;obstacle35;obstacle36;obstacle37;obstacle38;obstacle39;obstacle40;
%     obstacle41;obstacle42;obstacle43;obstacle44;obstacle45;obstacle46;obstacle47;obstacle48;obstacle49;obstacle50;
%     obstacle51;obstacle52;obstacle53;obstacle54;obstacle55;obstacle56;obstacle57;obstacle58;obstacle59;obstacle60;
%     obstacle61;obstacle62;obstacle63;obstacle64;obstacle65;obstacle66;obstacle67;obstacle68;obstacle69;obstacle70;
%     obstacle71];
obstacle111 = [5,10,4,4];   
obstacle222 = [15,10,4,4];  
obstacle333 = [10,20,2,4];  
obstacle444=[0,20,4,8];
obstacle555=[6,22,2,4];
obstacle666=[0,5,2,12];
obstacle777=[2,5,2,2];
obstacle888=[8,5,2,2];
obstacle999=[6,3,4,2];
obstacle101=[14,0,6,6];
obstacle102=[24,0,4,4];
obstacle103=[24,6,2,2];
obstacle104=[24,6,2,2];
obstacle105=[22,6,2,2];
obstacle106=[28,15,4,10];
obstacle107=[12,14,2,4];
obstacle108=[14,26,10,2];
obstacle109=[20,26,2,2];
% obstacle100=[16,18,8,2];
obstacle100=[16,16,8,4];
% obstacle200=[16,16,2,2];
% obstacle201=[22,16,2,2];
obstacle202=[18,24,2,2];

obstacle203=[0,0,0.4,30];
obstacle204=[0.4,0,29.6,0.4];
obstacle205=[0,29.6,30,0.4];
obstacle206=[29.6,0,0.4,29.5];

% obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
%     obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle200;obstacle201;obstacle202
%     obstacle203;obstacle204;obstacle205;obstacle206];
obstacle=[obstacle111;obstacle222;obstacle333;obstacle444;obstacle555;obstacle666;obstacle777;obstacle888;obstacle999;
    obstacle101;obstacle102;obstacle103;obstacle104;obstacle105;obstacle106;obstacle107;obstacle108;obstacle109;obstacle100;obstacle202
    obstacle203;obstacle204;obstacle205;obstacle206];
obs=obstacle;

for i=1:size(obs,1)
Obs=[obs(:,1)+obs(:,3)./2 obs(:,2)+obs(:,4)./2];
end

num_obc=size(Obs,1); 
num_path=size(cut_path,1);
xTarget=cut_path(num_path,1);
yTarget=cut_path(num_path,2);

xm=cut_path(1,1);
ym=cut_path(1,2);

 %angle_S=pi;
 angle_node=sn_angle(cut_path(1,1),cut_path(1,2),cut_path(2,1),cut_path(2,2));
 
 %zhuangjiao_node=angle_S-angle_node;
x=[xm ym angle_node 0 0]';

global dt;  
dt=0.1;]
%G_goal=path_node(num_path,:);


 obstacle1=Obs;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%     

obstacleR=0.8;


Kinematic = [1.0, toRadian(20.0), 0.2, toRadian(50.0), 0.01, toRadian(1)];
evalParam = [0.05,  0.3,  0.1,0.05, 3];
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

MAX_X=Area_MAX(1,1);
MAX_Y=Area_MAX(1,2);
result.x=[];

goal=cut_path(2,:);

for i=1:50000
  
    dang_node=[x(1,1) x(2,1)];
    dis_ng=distance(dang_node(1,1),dang_node(1,2),xTarget,yTarget);
    if num_path==2||dis_ng<1
        Ggoal=[xTarget yTarget];
    else
        Ggoal=Target_node(dang_node,cut_path,Obs_dong,xTarget,yTarget,goal);
    end
    goal=Ggoal;
    % obstacle=OBSTACLE(Obs_Closed,Obs_dong,path_node);
    obstacle_all=[obstacle1;Obs_dong];
    [u,traj]=DynamicWindowApproach(x,Kinematic,goal,evalParam,obstacle_all,obstacleR,B);
   
    x=f(x,u);
    result.x=[result.x; x'];

    
    
  
    %if norm(x(1:2)-G_goal')<0.2
    if dis_ng<0.2
        disp('Arrive Goal!!');break;
    end

    %====Animation====
 hold off;
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
   ArrowLength=0.5;

     quiver(x(1),   x(2),  ArrowLength*cos(x(3)),  ArrowLength*sin(x(3)),'ok');hold on;
    
    %  x=[x(m),y(m),yaw(Rad),v(m/s),w(rad/s)]
    plot(result.x(:,1), result.x(:,2),'-b','linewidth',1.5);hold on;

%     plot(goal(1)+0.5,goal(2)+0.5,'*r')
    plot(goal(1)',goal(2)','yo-','MarkerFaceColor','y');hold on;
   
     

    if ~isempty(traj)
        for it=1:length(traj(:,1))/5 % 
            ind=1+(it-1)*5;
             plot(traj(ind,:),traj(ind+1,:),'-g','linewidth',2);hold on;

        end
    end


      axis([0 MAX_X 0 MAX_Y])             
     for ob=1:size(obs,1)
      rectangle('position',[obs(ob,1),obs(ob,2),obs(ob,3),obs(ob,4)],'edgecolor','k','facecolor','k');
     end
     plot( Line_path(:,1), Line_path(:,2),'m:','linewidth',1); 
% 
%      plot(Start0(1,1)+.5,Start0(1,2)+.5,'ro-','MarkerFaceColor','r');
%      text(Start0(1,1)+1,Start0(1,2)+1.5,'S','fontsize',18')
% 
%     plot(xTarget+.5,yTarget+.5,'go-','MarkerFaceColor','g');
%     text(xTarget+1,yTarget+1.5,'T','fontsize',18')
 plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);
%  
    dong_num=size(Obs_dong,1);
    for i_d=1:1:dong_num
      x_do=Obs_dong(i_d,1);
      y_do=Obs_dong(i_d,2);
      fill([x_do,x_do+2,x_do+2,x_do],[y_do,y_do,y_do+2,y_do+2],[1 0 0]);
    end
    grid on; 
    drawnow;
    %movcount=movcount+1;
    %mov(movcount) = getframe(gcf);% 
    
end

a=result.x;

%movie2avi(mov,'movie.avi');
 





 

 

 

 

 

