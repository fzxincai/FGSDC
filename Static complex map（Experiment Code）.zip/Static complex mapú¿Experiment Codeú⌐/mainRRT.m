function cut_path=mainRRT(A,B,obstacle111,obstacle222,obstacle333,obstacle444,obstacle555,obstacle666,obstacle777,obstacle888,obstacle999,obstacle101,obstacle102,obstacle103,obstacle104,obstacle105,obstacle106,obstacle107,obstacle108,obstacle109,obstacle100,obstacle202,obstacle203,obstacle204,obstacle205,obstacle206)

Ll = []; Tt = []; Node = []; Cut_L=[]; All_Iterations = []; 
for j=1:1:1      


p=0.1;         
start_pose =A;       
global goal_pose;
goal_pose = B;   
global step;
step = 1;               
r = 2*step;              
global kp;              
kp=1;
bias = 0.3;             
numNodes = 5000;         
counter = 0;
global x_max;global y_max;
x_max = 30;
y_max = 30;
global angle;       
angle = 60; 

 global obstacle1;global obstacle2;global obstacle3;global obstacle4;global obstacle5;global obstacle6;global obstacle7;global obstacle8;global obstacle9;
 global obstacle1101;global obstacle1102;global obstacle1103;global obstacle1104;global obstacle1105;global obstacle1106;global obstacle1107;global obstacle1108;global obstacle1109;
 global obstacle1100;global obstacle2200;global obstacle2201;global obstacle2202;
 global obstacle2203;global obstacle2204;global obstacle2205;global obstacle2206;
% global obstacle11;global obstacle22;global obstacle33;
obstacle1 = obstacle111;     
obstacle2 = obstacle222;
obstacle3 = obstacle333;
obstacle4=obstacle444;
obstacle5=obstacle555;
obstacle6=obstacle666;
obstacle7=obstacle777;
obstacle8=obstacle888;
obstacle9=obstacle999;
obstacle1101=obstacle101;
obstacle1102=obstacle102;
obstacle1103=obstacle103;
obstacle1104=obstacle104;
obstacle1105=obstacle105;
obstacle1106=obstacle106;
obstacle1107=obstacle107;
obstacle1108=obstacle108;
obstacle1109=obstacle109;
obstacle1100=obstacle100;
% obstacle2200=obstacle200;
% obstacle2201=obstacle201;
obstacle2202=obstacle202;

obstacle2203=obstacle203;
obstacle2204=obstacle204;
obstacle2205=obstacle205;
obstacle2206=obstacle206;

obstacle=[obstacle1;obstacle2;obstacle3;obstacle4;obstacle5;obstacle6;obstacle7;obstacle8;obstacle9;obstacle1101;
    obstacle1102;obstacle1103;obstacle1104;obstacle1105;obstacle1106;obstacle1107;obstacle1108;obstacle1109;obstacle1100;
    obstacle2202;obstacle2203;obstacle2204;obstacle2205;obstacle2206];
global path_V;
path_V= ([start_pose,-1]);       
path_E = [];                    
path=[];                          


figure(j)
axis([0 x_max 0 y_max])
for i=1:size(obstacle,1)
    rectangle('Position',obstacle(i,:),'edgecolor','k','facecolor','k')
end
or = 0.2;                                 
global obstacle11;global obstacle22;global obstacle33;global obstacle44;global obstacle55;global obstacle66;global obstacle77;global obstacle88;global obstacle99;
global obstacle10;global obstacle12;global obstacle13;global obstacle14;global obstacle15;global obstacle16;global obstacle17;global obstacle18;global obstacle19;global obstacle20;
global obstacle21;global obstacle23;global obstacle24;global obstacle25;global obstacle26;global obstacle27;global obstacle28;
obstacle11 = [obstacle1(1)-or,obstacle1(2)-or,obstacle1(3)+2*or,obstacle1(4)+2*or];  
obstacle22 = [obstacle2(1)-or,obstacle2(2)-or,obstacle2(3)+2*or,obstacle2(4)+2*or];
obstacle33 = [obstacle3(1)-or,obstacle3(2)-or,obstacle3(3)+2*or,obstacle3(4)+2*or];
obstacle44 = [obstacle4(1)-or,obstacle4(2)-or,obstacle4(3)+2*or,obstacle4(4)+2*or];     
obstacle55 = [obstacle5(1)-or,obstacle5(2)-or,obstacle5(3)+2*or,obstacle5(4)+2*or];
obstacle66 = [obstacle6(1)-or,obstacle6(2)-or,obstacle6(3)+2*or,obstacle6(4)+2*or];
obstacle77 = [obstacle7(1)-or,obstacle7(2)-or,obstacle7(3)+2*or,obstacle7(4)+2*or];   
obstacle88 = [obstacle8(1)-or,obstacle8(2)-or,obstacle8(3)+2*or,obstacle8(4)+2*or];
obstacle99 = [obstacle9(1)-or,obstacle9(2)-or,obstacle9(3)+2*or,obstacle9(4)+2*or];
obstacle10 = [obstacle1101(1)-or,obstacle1101(2)-or,obstacle1101(3)+2*or,obstacle1101(4)+2*or];     %�ϰ���
obstacle12 = [obstacle1102(1)-or,obstacle1102(2)-or,obstacle1102(3)+2*or,obstacle1102(4)+2*or];
obstacle13 = [obstacle1103(1)-or,obstacle1103(2)-or,obstacle1103(3)+2*or,obstacle1103(4)+2*or];
obstacle14 = [obstacle1104(1)-or,obstacle1104(2)-or,obstacle1104(3)+2*or,obstacle1104(4)+2*or];     %�ϰ���
obstacle15 = [obstacle1105(1)-or,obstacle1105(2)-or,obstacle1105(3)+2*or,obstacle1105(4)+2*or];
obstacle16 = [obstacle1106(1)-or,obstacle1106(2)-or,obstacle1106(3)+2*or,obstacle1106(4)+2*or];
obstacle17 = [obstacle1107(1)-or,obstacle1107(2)-or,obstacle1107(3)+2*or,obstacle1107(4)+2*or];     %�ϰ���
obstacle18 = [obstacle1108(1)-or,obstacle1108(2)-or,obstacle1108(3)+2*or,obstacle1108(4)+2*or];
obstacle19 = [obstacle1109(1)-or,obstacle1109(2)-or,obstacle1109(3)+2*or,obstacle1109(4)+2*or];
obstacle20 = [obstacle1100(1)-or,obstacle1100(2)-or,obstacle1100(3)+2*or,obstacle1100(4)+2*or];     %�ϰ���
% obstacle21 = [obstacle2200(1)-or,obstacle2200(2)-or,obstacle2200(3)+2*or,obstacle2200(4)+2*or];
% obstacle23 = [obstacle2201(1)-or,obstacle2201(2)-or,obstacle2201(3)+2*or,obstacle2201(4)+2*or];
obstacle24 = [obstacle2202(1)-or,obstacle2202(2)-or,obstacle2202(3)+2*or,obstacle2202(4)+2*or];

obstacle25 = [obstacle2203(1)-or,obstacle2203(2)-or,obstacle2203(3)+2*or,obstacle2203(4)+2*or];     %�ϰ���
obstacle26 = [obstacle2204(1)-or,obstacle2204(2)-or,obstacle2204(3)+2*or,obstacle2204(4)+2*or];
obstacle27 = [obstacle2205(1)-or,obstacle2205(2)-or,obstacle2205(3)+2*or,obstacle2205(4)+2*or];
obstacle28 = [obstacle2206(1)-or,obstacle2206(2)-or,obstacle2206(3)+2*or,obstacle2206(4)+2*or];


plot(A(1),A(2),'go-','MarkerFaceColor','g','Markersize',10);
plot(B(1),B(2),'ro-','MarkerFaceColor','r','Markersize',10);;
hold on
% hold on
% plot(start_pose,'m*','LineWidth',10);
% hold on
% 
% hold on

tic
rrts=rrt;
for i = 1:1:numNodes
    if rand(1)<=p           
        q_rand = goal_pose;
    else
        q_rand = [floor(rand(1)*x_max) floor(rand(1)*y_max)];
    end
    [nearest_point,I]=rrts.nearestpoint(q_rand);             
    new_point = rrts.APF_newpoint(nearest_point,q_rand);       
    
% %     if rrts.noCollision(new_point, nearest_point, obstacle1)&&rrts.noCollision(new_point, nearest_point, obstacle2)&&rrts.noCollision(new_point, nearest_point, obstacle3)&&rrts.angel_limit(path_V,nearest_point,new_point)&&rrts.noCollision(new_point, nearest_point, obstacle4)&&rrts.noCollision(new_point, nearest_point, obstacle5)&&rrts.noCollision(new_point, nearest_point, obstacle6)&&rrts.noCollision(new_point, nearest_point, obstacle7)&&rrts.noCollision(new_point, nearest_point, obstacle8)&&rrts.noCollision(new_point, nearest_point, obstacle9)...
%             &&rrts.noCollision(new_point, nearest_point, obstacle1101)&&rrts.noCollision(new_point, nearest_point, obstacle1102)&&rrts.noCollision(new_point, nearest_point, obstacle1103)&&rrts.noCollision(new_point, nearest_point, obstacle1104)&&rrts.noCollision(new_point, nearest_point, obstacle1105)&&rrts.noCollision(new_point, nearest_point, obstacle1106)&&rrts.noCollision(new_point, nearest_point, obstacle1107)&&rrts.noCollision(new_point, nearest_point, obstacle1108)&&rrts.noCollision(new_point, nearest_point, obstacle1109)...
%             &&rrts.noCollision(new_point, nearest_point, obstacle1100)&&rrts.noCollision(new_point, nearest_point, obstacle2202)&&rrts.noCollision(new_point, nearest_point, obstacle2202)&&rrts.noCollision(new_point, nearest_point, obstacle2203)&&rrts.noCollision(new_point, nearest_point, obstacle2204)&&rrts.noCollision(new_point, nearest_point, obstacle2205)&&rrts.noCollision(new_point, nearest_point, obstacle2206)
        if rrts.noCollision(new_point, nearest_point, obstacle11)&&rrts.noCollision(new_point, nearest_point, obstacle22)&&rrts.noCollision(new_point, nearest_point, obstacle33)&&rrts.noCollision(new_point, nearest_point, obstacle44)&&rrts.noCollision(new_point, nearest_point, obstacle55)&&rrts.noCollision(new_point, nearest_point, obstacle66)&&rrts.noCollision(new_point, nearest_point, obstacle77)&&rrts.noCollision(new_point, nearest_point, obstacle88)&&rrts.noCollision(new_point, nearest_point, obstacle99)&&rrts.angel_limit(path_V,nearest_point,new_point)...
            &&rrts.noCollision(new_point, nearest_point, obstacle10)&&rrts.noCollision(new_point, nearest_point, obstacle12)&&rrts.noCollision(new_point, nearest_point, obstacle13)&&rrts.noCollision(new_point, nearest_point, obstacle14)&&rrts.noCollision(new_point, nearest_point, obstacle15)&&rrts.noCollision(new_point, nearest_point, obstacle16)&&rrts.noCollision(new_point, nearest_point, obstacle17)&&rrts.noCollision(new_point, nearest_point, obstacle18)&&rrts.noCollision(new_point, nearest_point, obstacle19)...
            &&rrts.noCollision(new_point, nearest_point, obstacle20)&&rrts.noCollision(new_point, nearest_point, obstacle24)&&rrts.angel_limit(path_V,nearest_point,new_point)...
            &&rrts.noCollision(new_point, nearest_point, obstacle25)&&rrts.noCollision(new_point, nearest_point, obstacle26)&&rrts.noCollision(new_point, nearest_point, obstacle27)&&rrts.noCollision(new_point, nearest_point, obstacle28)
%         &&rrts.noCollision(new_point, nearest_point, obstacle21)&&rrts.noCollision(new_point, nearest_point, obstacle23
        length = 0;                                 
        path_tem= [nearest_point,I]; 
        while(path_tem(1,3)>0)   
            length = length+ norm(path_tem(1,1:2)-path_V(path_tem(1,3),1:2));                                                         % �ټ����ʼ�ڵ㵽��ǰ�ڵ�ľ���
            path_tem=path_V(path_tem(1,3),1:3);
        end
        length = length + norm(new_point-nearest_point(1:2));        
        min = length;            
        for j = 1: size(path_V,1)                                        
            length2=0;
            if rrts.angel_dist(path_V(j,1:2),new_point)<=r               
                path_tem = path_V(j,1:3);                                
                while(path_tem(1,3)>0)   
                    length2 = length2+ norm(path_tem(1,1:2)-path_V(path_tem(1,3),1:2));                                                         % �ټ����ʼ�ڵ㵽��ǰ�ڵ�ľ���
                    path_tem=path_V(path_tem(1,3),1:3);  
                end
                length2 = length2 + norm(new_point-path_V(j,1:2));        
                if length2<min
                    min = length2;    
                    nearest_point=path_V(j,1:2);
                    I=j;
                end
            end

        end
%         line([nearest_point(1),new_point(1)],[nearest_point(2),new_point(2)],'color','b','LineWidth', 2);   % ������չ����
%         line([nearest_point(1),new_point(1)],[nearest_point(2),new_point(2)],'Marker','.','LineStyle','-','color','b');
          line([nearest_point(1),new_point(1)],[nearest_point(2),new_point(2)],'color',[0.5 0.5 0.5],'LineWidth', 1);
        counter=counter+1;M(counter)=getframe;
        path_V = [path_V;[new_point,I]];     
    end
 
    if (norm((new_point-goal_pose),2)<=bias)     
        break;
    end      
end
Iterations = i;
t=toc;           


pose1 = path_V(size(path_V,1),1:3);
while (pose1(1,3) > 0)
    path=[pose1(1,1:2);path];
    pose1 = path_V(pose1(1,3),1:3);   
end
path = [path_V(1,1:2);path];   

 plot(path(:,1),path(:,2),'b','linewidth',2); 



cut_path=[];    
cut_path = [cut_path;start_pose];      
 i=1;
 while i<size(path,1)
%  for i=1:size(path,1)
    
       j=i+1;
    while j<=size(path,1)  
    
         if rrts.noCollision(path(i,1:2), path(j,1:2), obstacle20)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle11)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle22)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle33)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle44)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle55)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle66)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle77)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle88)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle99)...
                 &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle10)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle11)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle12)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle13)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle14)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle15)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle16)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle17)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle18)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle19)...
                 &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle20)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle24)...
                 &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle25)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle26)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle27)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle28)
%             if rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle3)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle4)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle5)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle6)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle7)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle8)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle9)...
%                  &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1101)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1102)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1103)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1104)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1105)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1106)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1107)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1108)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1109)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle1100)...
%                  &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2203)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2204)...
%                  &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2205)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2206)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2202)
% %              &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle21)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle23) &&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2200)&&rrts.noCollision(path(i,1:2), path(j,1:2), obstacle2201)
             j=j+1;
            if j==size(path,1)
                cut_path=[cut_path;path(j-1,1:2);goal_pose];
                i=j;
                break;
            end               
        else
            cut_path=[cut_path;path(j-1,1:2)];
            i=j-1;      
            break;
        end
    end
   end


% plot(cut_path(:,1)',cut_path(:,2)','color','g','LineWidth',2);
plot(cut_path(:,1)',cut_path(:,2)','color','g','LineWidth', 2);
% plot(cut_path(:,1)+0.5',cut_path(:,2)+0.5','color','g','LineWidth',2);
hold on;


L=0;
for i=1:(size(path,1)-1)
    L=L+norm(path(i,1:2)-path(i+1,1:2),2);
end

cut_l=0;
for i=1:(size(cut_path,1)-1)
   cut_l=cut_l+norm(cut_path(i,1:2)-cut_path(i+1,1:2),2);
end
Ll = [Ll,L];                 
Cut_L = [Cut_L,cut_l];      
Tt = [Tt,t];                 
Node = [Node,size(path,1)]; 
All_Iterations = [All_Iterations,Iterations];    
end
% disp('Original path length');  mean(Ll)
disp('Global path length');  mean(Cut_L)
disp('spent times');  mean(Tt)
disp('Number of path nodes');  mean(Node)
disp('Number of iterations');  mean(All_Iterations)

cut_path
node_ponit=size(cut_path,1)


