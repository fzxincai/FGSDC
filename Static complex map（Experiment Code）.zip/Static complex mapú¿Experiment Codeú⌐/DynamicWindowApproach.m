function [u,trajDB]=DynamicWindowApproach(x,model,goal,evalParam,ob,R,B)
% Dynamic Window [vmin,vmax,wmin,wmax]
Vr=CalcDynamicWindow(x,model);

[evalDB,trajDB]=Evaluation(x,Vr,goal,ob,R,model,evalParam,B);
if isempty(evalDB)
    disp('no path to goal!!');
    u=[0;0];return;
end

evalDB=NormalizeEval(evalDB);

feval=[];
for id=1:length(evalDB(:,1))
    feval=[feval;evalParam(1:4)*evalDB(id,3:6)'];
end
evalDB=[evalDB feval];
 
[maxv,ind]=max(feval);
u=evalDB(ind,1:2)';% 