function [v] = downRank(point,row)

v = (point(2)-1)*row+ point(1);
end