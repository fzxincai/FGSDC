function dist=CalcDistEval(x,ob,R)

dist=100;
for io=1:length(ob(:,1))
    disttmp=norm(ob(io,:)-x(1:2)')-R;
    if dist>disttmp
        dist=disttmp;
    end
end
 
if dist>=2*R
    dist=2*R;
end