function [x,traj]=GenerateTrajectory(x,vt,ot,evaldt,model)

global dt;
time=0;
u=[vt;ot];
traj=x;
while time<=evaldt
    time=time+dt;
    x=f(x,u);
    traj=[traj x];
end